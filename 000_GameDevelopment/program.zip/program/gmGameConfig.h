﻿// gmGameConfig.h
#pragma once
#include <cstdint>      // uint8_t
#include <cstddef>      // size_t

namespace gm
{
    // マップサイズ（Excel側と完全一致）
    static const int MAP_CHIP_WIDTH     = 256;
    static const int MAP_CHIP_HEIGHT    = 256;

    // ゲーム世界座標系での1セル(チップ)の大きさ
    static const float CELL_SIZE = 100.0f;

    // マップデータのパス
    static const char* const MAP_FILE_PATH = "resource/map/map.bin";

    // 海流マップデータのパス
    static const char* const FLOW_STO_E_PATH = "resource/map/ocean_flow_StoE.bin";
    static const char* const FLOW_STO_N_PATH = "resource/map/ocean_flow_StoN.bin";
    static const char* const FLOW_STO_W_PATH = "resource/map/ocean_flow_StoW.bin";

    // 航路データのパス(プレフィックス)
    // "route_1.bin", "route_2.bin", ... のように1始まりの連番を後ろに付けて読み込む。
    // 何本の航路が存在するかを別途持たず、
    // このプレフィックス+連番で読み込みに失敗するまで走査する方式
    // (gmMapManager::LoadRoutes()参照)。
    static const char* const ROUTE_FILE_PATH_PREFIX = "resource/map/route_";

    // 描画範囲の定義
    static const float RENDER_DISTANCE      = 6400.0f;                              // カメラからの描画距離
    static const float RENDER_DISTANCE_SQ   = RENDER_DISTANCE * RENDER_DISTANCE;    // 距離比較を高速化するための2乗値
                                                                                    // ※ 距離の比較は本来sqrt()が必要だが、
                                                                                    //    両辺を2乗しても大小関係は変わらないため、
                                                                                    //    平方根の計算を省略できる

    // 画像ファイルパス
    static const char* const GRAPHICS_FILE_PATH__OCEAN_FLOW_ARROW       = "resource/graphics/test/wf_arrow.png";

    // VFX(エフェクト)関連パス
    static const char* const VFX_SPRITE_METADATA_CSV_PATH               = "resource/csv/tktk_sprite_metadata.csv";
    static const char* const VFX_EFFECT_GRAPHICS_DIR                    = "resource/graphics/effect/";

    // 武器関連パス
    static const char* const GRAPHICS_FILE_PATH__SPLIT_PROJECTILE_BALL  = "resource/graphics/weapon/split_projectile_ball.png"; // 割り砲弾(鉄球)用テクスチャ。黒単色を想定



    // ------------------------------------------------------------
    // 航路の可視化(NPC交易船が辿る航路を、ゲーム内にリボンメッシュとして描画する)
    // ------------------------------------------------------------
    // 素材画像(横長のグラデーション。縦方向(V)が中央最明→上下端でアルファ0、
    // 横方向(U)は無地でよい。gmRouteVisualizer参照)
    static const char* const GRAPHICS_FILE_PATH__ROUTE_RIBBON = "resource/graphics/route/route_ribbon_gradient.png";

    // 空中リボン(水平・垂直の十字クロス)を、海面(y=0)からどれだけ高い位置に固定するか。
    // 波の高さは追わず常に一定(モノレールのレールのように)。
    static const float ROUTE_RIBBON_ALTITUDE = 25.0f;

    // 空中リボン(水平・垂直とも共通)の帯の幅(world単位)
    static const float ROUTE_RIBBON_WIDTH = 60.0f;

    // 中心線(遠心的Catmull-Romで補間した曲線)をポリライン化する際のサンプリング間隔(world単位)。
    // 小さいほど滑らかになるが、頂点数・ドローコール準備コストが増える。
    static const float ROUTE_RIBBON_SAMPLE_STEP = 25.0f;

    // 描画カリング用にチャンク分割する際の、1チャンクあたりの目安の長さ(world単位)。
    // gmIceberg等と同じ距離カリング(RENDER_DISTANCE_SQ)をチャンク単位で適用する。
    static const float ROUTE_RIBBON_CHUNK_LENGTH = 700.0f;

    // 始点(S)・終点(G)付近でアルファを0まで滑らかにフェードさせる区間の長さ(world単位)
    static const float ROUTE_RIBBON_FADE_LENGTH = 150.0f;

    // UVスクロールでテクスチャが1周する距離(world単位)。値が小さいほど帯の模様が細かく繰り返す。
    static const float ROUTE_RIBBON_UV_REPEAT_LENGTH = 400.0f;

    // UVスクロール速度(1秒あたりに進むUV量。ROUTE_RIBBON_UV_REPEAT_LENGTHに対する割合)。
    // 各航路はS→Gの一方向のみなので、この方向へ流れる=「今どちら向きの航路か」を示す意味を持つ。
    // 0を指定するとスクロールなし(静止した帯)になる。
    static const float ROUTE_RIBBON_SCROLL_SPEED = 0.35f;

    // 海面の影用リボン(位置確認用、水平のみ・空中リボンより控えめな見た目)関連
    static const float   ROUTE_SHADOW_RIBBON_HEIGHT_OFFSET  = 2.0f;   // 水面メッシュとのZファイティング回避用の微小オフセット(海面y=0からの高さ)
    static const float   ROUTE_SHADOW_RIBBON_WIDTH_SCALE    = 0.4f;   // 空中リボン幅に対する、影リボンの幅の比率
    static const uint8_t ROUTE_SHADOW_RIBBON_ALPHA_SCALE    = 90;     // 影リボンの最大アルファ(0〜255。空中リボンより控えめにする)
    static const uint8_t ROUTE_SHADOW_RIBBON_COLOR_SCALE    = 140;    // 影リボンの頂点色に掛ける明度スケール(0〜255。暗めにする)


    // ------------------------------------------------------------
    // NPC交易船(gmTradeShip / gmTradeShipManager)
    // ------------------------------------------------------------
    // モデル・テクスチャのパス。
    // NOTE: S2〜S10等の専用モデルに差し替え予定だが、変換(mv1化)が済むまでの暫定として
    //       プレイヤー船と同じS1.mv1を使う(色味だけTRADE_SHIP_TINT_COLORで変える)。
    //       差し替える際はこの2つのパスを書き換えるだけでよい。
    static const char* const TRADE_SHIP_MESH_FILE_PATH          = "resource/mesh/mv/ship/TradeShip.mv1";
    static const char* const TRADE_SHIP_TEXTURE_FILE_PATH       = "resource/graphics/ship/tradeship/Textures.png";
    static const char* const TRADE_SHIP_NORMAL_MAP_FILE_PATH    = "resource/graphics/ship/tradeship/Normals.png";

    static const float       TRADE_SHIP_MESH_SCALE          = 0.01f;

    // プレイヤー船と見分けやすいよう、頂点ディフューズカラーで色味を変える(交易船=金のコンセプト)。
    // dxe::Mesh::setMtrlDiffuse()へtnl::Vector3(R,G,B)として渡す想定(0.0〜1.0)。
    // gmGameConfig.hは軽量に保ちたいため、ここではtnl::Vector3型を使わずfloat 3つに分けている。
    static const float TRADE_SHIP_TINT_COLOR_R = 1.0f;
    static const float TRADE_SHIP_TINT_COLOR_G = 0.85f;
    static const float TRADE_SHIP_TINT_COLOR_B = 0.5f;

    // コライダー(setupManualColliderへそのまま渡す値)。
    static const float TRADE_SHIP_COLLIDER_RADIUS = 40.0f;
    static const float TRADE_SHIP_COLLIDER_LENGTH = 120.0f;

    // 巡航速度(dynamics_.targetSpeedにそのまま渡す。gmShip::SPEED_LEVELSと同じ単位系)
    static const float TRADE_SHIP_CRUISE_SPEED = 0.4f;

    // 操舵AI: 現在位置から中心線上でどれだけ先の点を「狙う点」にするか(world単位)。
    // 大きいほど穏やかに、小さいほど機敏に(ただし曲がりきれず外側にカットしやすく)なる。
    static const float TRADE_SHIP_LOOKAHEAD_DISTANCE = 250.0f;

    // 操舵AI: 狙う点への角度差(ラジアン)からtargetRudderへ変換する際のゲイン。
    // 角度差×このゲイン をそのまま-1〜1にクランプしてtargetRudderにする。
    static const float TRADE_SHIP_STEERING_GAIN = 1.2f;

    // 終点(G)までの残り距離がこれ未満になったら到達とみなし、デスポーンする(world単位)
    static const float TRADE_SHIP_ARRIVAL_THRESHOLD = 80.0f;

    // 進捗停滞タイムアウト+ワープの保険。
    // 経路上の進捗(累積距離のハイウォーターマーク)がこの秒数だけ更新されなければ、
    // 最寄りの中心線上の点(＋少し先)へワープし、向きも補正する。
    static const float TRADE_SHIP_STUCK_TIMEOUT = 90.0f;
    // ワープ先を、停滞検知位置からさらにこれだけ先に進めておく(同じ地点で即再発するのを防ぐ)
    static const float TRADE_SHIP_WARP_ADVANCE_DISTANCE = 150.0f;

    // 島衝突時の一時バック挙動。SPEED_LEVELSの負の段階(後退)を使う。
    static const float TRADE_SHIP_COLLISION_BACKOFF_SPEED = -0.5f;      // バック中のtargetSpeed(SPEED_LEVELS[1]相当)
    static const float TRADE_SHIP_COLLISION_BACKOFF_DURATION = 2.0f;    // バックを続ける秒数

    // 交易船スポナー
    static const size_t TRADE_SHIP_MAX_ENTITIES = 6;            // 同時に存在できる交易船の上限(暴走防止)
    static const float  TRADE_SHIP_SPAWN_INTERVAL_MIN = 20.0f;  // 秒
    static const float  TRADE_SHIP_SPAWN_INTERVAL_MAX = 40.0f;



    // ------------------------------------------------------------
    // 船のHP・被弾・撃沈演出(gmShip共通。プレイヤー船・交易船の両方に効く)
    // ------------------------------------------------------------
    static const float SHIP_MAX_HP = 100.0f;

    // 流氷との接触ダメージ。
    // 「初回接触(または猶予明け後の再接触)は大ダメージ、以後接触し続けている間は
    //  小さな継続ダメージ(DoT)」というモデル。
    // 氷山インスタンスごとに猶予タイマーを持つため、
    // 短時間で接触→離脱→再接触を繰り返しても大ダメージが連発しない
    static const float SHIP_ICEBERG_BIG_HIT_DAMAGE      = 25.0f;    // 初回(または猶予明け)接触時の大ダメージ
    static const float SHIP_ICEBERG_DOT_DAMAGE_PER_SEC  = 5.0f;     // 接触し続けている間の継続ダメージ(秒あたり)
    static const float SHIP_ICEBERG_CONTACT_GRACE_SEC   = 3.0f;     // 大ダメージ後、同じ氷山からの大ダメージを抑止する猶予秒数

    // 撃沈演出(Destroyed状態)。
    // 「垂直方向に傾きながら沈み、完全に水面下へ潜ることで消えたとみなす」という演出を
    // gmShip::updateDestroyed()で共通実装する。
    // 傾き・沈み込みとも、経過時間の割合(t)をイーズイン(t^EASE_POWER)してから適用することで、
    // 始めはゆっくり、徐々に加速していく動きにしている。
    static const float SHIP_DESTROYED_TILT_TARGET_RAD   = 0.9f;   // 最終的な傾き角度(ラジアン。約51度)
    static const float SHIP_DESTROYED_SUBMERGE_DEPTH    = 150.0f; // 死亡時のY座標から、これだけ沈んだら完全に消えたとみなす(world単位)
    static const float SHIP_DESTROYED_DURATION          = 5.0f;   // 演出全体の尺(秒)。この時間でTILT_TARGET/SUBMERGE_DEPTHに到達する
    static const float SHIP_DESTROYED_EASE_POWER        = 2.0f;   // イーズインの強さ(t^EASE_POWER)。大きいほど始めがよりゆっくりになる

    // 傾きは全体の前半で完了させ、沈み込みは傾きが終わりかけた頃から始めて
    // 全体の終わりで完了する、という時間差を付ける(SHIP_DESTROYED_DURATIONに対する割合で指定)。
    // 例: TILT_PORTION=0.6, SINK_START_PORTION=0.4なら、傾きは0〜60%の区間で完了し、
    // 沈み込みは40%〜100%の区間で進む(40〜60%の間は両方同時に進む重なり区間)。
    static const float SHIP_DESTROYED_TILT_PORTION = 0.6f;
    static const float SHIP_DESTROYED_SINK_START_PORTION = 0.25f;

    
    // ------------------------------------------------------------
    // ウォレット(資金・溶かす経験値)関連
    // ------------------------------------------------------------
    // 交易船が終点(G)へ満タンHPで到着した場合の資金報酬(基準値)。
    // 実際の報酬 = この値 × (到着時のHP ÷ 最大HP)。ダメージを受けているほど減額される。
    static const int TRADE_SHIP_ARRIVAL_REWARD_BASE = 1000;

    // 流氷への溶かすダメージ1ポイントあたりに得られる、溶かす経験値の量。
    // 1.0でダメージ量とそのまま等倍(通常弾・炎放射どちらのダメージにも同じ比率で適用される)。
    static const float MELT_EXP_PER_DAMAGE_POINT = 1.0f;
}
