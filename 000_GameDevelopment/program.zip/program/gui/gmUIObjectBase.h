#pragma once
#include <dxe.h>

namespace gm {
    class gmUIObjectBase {
    public:
        gmUIObjectBase(const tnl::Vector2f& pos);
        virtual ~gmUIObjectBase() = default;

        virtual void update(float dt) = 0;
        virtual void draw() = 0;

    protected:
        tnl::Vector2f position_;   // �X�N���[�����W
        float alpha_ = 1.0f;      // �����x
    };
}