#pragma once
#include <cstdint>
#include "../gmGameConfig.h"

namespace gm
{
    // map.bin ��p���[�_�[
    class gmMapLoader
    {
    public:
        // outMap �� uint8_t[MAP_H][MAP_W] ��n��
        bool Load(const char* filePath, uint8_t outMap[MAP_CHIP_HEIGHT][MAP_CHIP_WIDTH]);
    };
}
