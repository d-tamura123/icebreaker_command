#include "gmMapLoader.h"
#include <DxLib.h>

namespace gm
{
    bool gmMapLoader::Load(const char* filePath, uint8_t outMap[MAP_CHIP_HEIGHT][MAP_CHIP_WIDTH])
    {
        int fh = FileRead_open(filePath);
        if (fh == 0)
        {
            return false; // �ǂݍ��ݎ��s
        }

        // map.bin �� 256�~256 �� 1byte �z��
        const int MAP_SIZE = MAP_CHIP_WIDTH * MAP_CHIP_HEIGHT;

        // DXLib �� FileRead_read �� memcpy �Ɠ�������
        FileRead_read(outMap, MAP_SIZE, fh);

        FileRead_close(fh);
        return true;
    }
}
